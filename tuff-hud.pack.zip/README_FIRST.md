# Tuff Advance Hud [ QBCore , ESX , QBOX , vMenu and Standalone ]

Thank you for Purchasing Tuff Advance Hud !

## Installation

- Make a new folder in your resource folder named [tuff].
- Download the script from your keymaster.
- Copy the [tuff-hud] folder from the keymaster file you just downloaded and paste it inside the folder named [tuff].
- Start the scripts at the end or after oxlib , to prevent any dependencies or server load issues.

Example of my "server.cfg" file : 👇

## My server.cfg File

ensure qb-core
ensure [qb]
ensure [standalone]
ensure [voice]
ensure [defaultmaps]
ensure [vehicles]
ensure ox_lib
ensure [tuff] -- Start my Scripts in a Folder like this !

- The script is basically Plug and Play , adjust config file to your liking and explore the script in-game.

## Documentation Page

Visit Tuff Scripts Documentation for detailed installation Guide !

- https://tuff-scripts.gitbook.io/tuff-scripts/

## Need Support Come to my Discord

- My Discord Username : tuffscripts
- Discord Invite: https://discord.gg/rJGkVkqcMe
- Tebex Link : https://tuff-scripts.tebex.io/
